# Asesmen Fikih Online 2026 — MTs Raudlatul Ulum VI

Aplikasi web asesmen 50 soal, 90 menit, penilaian server-side, hasil privat per peserta, dan dashboard admin. Paket ini adalah source code siap konfigurasi; **belum online** sampai Supabase dan hosting milik sekolah dikonfigurasi.

## Isi proyek
- `index.html` — antarmuka siswa dan admin.
- `supabase/schema.sql` — tabel dan RLS.
- `supabase/functions/start-assessment` — pendaftaran nomor peserta dan token sesi.
- `supabase/functions/submit-assessment` — kunci jawaban di server, koreksi otomatis, cegah pengiriman ganda.
- `supabase/functions/get-result` — endpoint hasil berdasarkan token.
- `supabase/functions/admin-data` — data dashboard setelah autentikasi dan pemeriksaan daftar admin.

## 1. Buat proyek Supabase
1. Buat proyek baru di https://supabase.com.
2. Buka **Project Settings → API**. Salin Project URL dan `anon/public` key.
3. Pada `index.html`, ganti:
   - `GANTI_DENGAN_SUPABASE_URL`
   - `GANTI_DENGAN_SUPABASE_ANON_KEY`
   Kunci anon boleh berada di browser karena akses tabel dibatasi RLS. **Jangan pernah memasukkan service_role key ke HTML.**
4. Buka SQL Editor, jalankan seluruh isi `supabase/schema.sql`.

## 2. Buat admin
1. Di Supabase → Authentication → Users → Add user, buat email dan password admin.
2. Salin UUID user tersebut.
3. Di SQL Editor jalankan:
   `insert into public.admin_users(user_id) values ('UUID-ADMIN-DI-SINI');`
4. Hanya UUID yang terdaftar di `admin_users` dapat membaca dashboard.

## 3. Deploy Edge Functions
Pasang Supabase CLI, login, lalu dari folder proyek:
```bash
supabase login
supabase link --project-ref PROJECT_REF
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=SERVICE_ROLE_KEY_ANDA
supabase secrets set SUPABASE_ANON_KEY=ANON_KEY_ANDA
supabase functions deploy start-assessment
supabase functions deploy submit-assessment
supabase functions deploy get-result
supabase functions deploy admin-data
```
`SUPABASE_URL` biasanya tersedia otomatis pada Edge Functions. Jika environment belum tersedia, set juga:
`supabase secrets set SUPABASE_URL=https://PROJECT_REF.supabase.co`

## 4. Hosting
### Vercel
1. Buat repository GitHub dan unggah `index.html` serta folder `supabase`.
2. Import repository di https://vercel.com.
3. Framework preset: **Other**; build command dan output directory dapat dikosongkan untuk situs statis.
4. Deploy. Bagikan URL Vercel kepada siswa.

### Netlify
1. Buka https://app.netlify.com/drop atau import repository.
2. Deploy folder proyek sebagai situs statis.
3. Pastikan `index.html` berada di root publik.

## 5. Cara penggunaan
- Siswa membuka link, mengisi nama, kelas, dan nomor peserta, lalu mulai.
- Setiap nomor peserta hanya bisa didaftarkan satu kali. Guru perlu memastikan daftar nomor peserta benar sebelum ujian.
- Siswa memilih jawaban, dapat menandai soal ragu, dan mengirim sebelum 90 menit.
- Setelah dikirim, nilai dihitung di Edge Function. Kunci jawaban tidak disertakan pada HTML.
- Admin login melalui tautan **Akses Admin** dengan akun yang telah dimasukkan ke `admin_users`.
- Dashboard menyediakan ringkasan, diagram, pencarian, CSV, dan cetak.

## Catatan penting sebelum ujian resmi
1. **Validasi identitas:** versi ini mencegah nomor peserta ganda, tetapi tidak memverifikasi identitas terhadap daftar siswa resmi. Untuk ujian berisiko tinggi, tambahkan PIN unik yang dibagikan sekolah atau impor roster resmi.
2. **Pemulihan koneksi:** token sesi disimpan di browser selama ujian, tetapi versi dasar ini belum melakukan sinkronisasi jawaban per klik. Jangan menutup browser/perangkat sebelum pengumpulan. Untuk kebutuhan produksi, tambahkan endpoint penyimpanan draft berkala dan mekanisme resume yang diuji.
3. **Penguncian pengiriman:** server menolak pengiriman kedua setelah `submitted_at` terisi. Pada saat dua permintaan bersamaan, uji beban dan tambahkan transaksi database/RPC atomik sebelum ujian skala besar.
4. **Pengacakan:** urutan soal dan opsi diacak pada browser; penilaian memakai teks jawaban dari bank soal server. Jangan mengubah teks opsi tanpa memperbarui kunci pada Edge Function.
5. **Diagram:** dashboard menghitung kategori Tinggi 86–100, Sedang 70–85, Rendah 0–69. Nilai 86 ke atas masuk Tinggi sesuai ketentuan.
6. **Logo:** siapkan file PNG transparan logo pesantren. Untuk mengganti emblem sementara di halaman pembuka, ganti elemen `<div class="seal">✦</div>` dengan `<img src="logo.png" ...>` dan letakkan `logo.png` di root proyek.
7. Lakukan simulasi minimal dengan akun admin dan beberapa akun peserta uji, termasuk nomor ganda, waktu habis, jawaban kosong, refresh halaman, dan dua pengiriman berdekatan.

## Struktur
```text
asesmen-fikih-online-2026/
├── index.html
└── supabase/
    ├── schema.sql
    └── functions/
        ├── start-assessment/index.ts
        ├── submit-assessment/index.ts
        ├── get-result/index.ts
        └── admin-data/index.ts
```

**Penting:** paket ini menyediakan fondasi aplikasi yang dapat dikonfigurasi. Sebelum dipakai untuk ujian resmi, selesaikan konfigurasi Supabase, deploy Edge Functions, lakukan uji end-to-end, dan pertimbangkan fitur PIN/roster serta penyimpanan draft otomatis.
