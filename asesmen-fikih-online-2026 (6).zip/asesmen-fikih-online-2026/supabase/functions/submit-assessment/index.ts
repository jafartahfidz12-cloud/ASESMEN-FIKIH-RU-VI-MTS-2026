import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, GET, OPTIONS"};
const json = (body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
const admin = createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const hash = async (s:string)=>{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")};

const KEY={"1": "Mengulangi wudu", "2": "Air mutlak", "3": "Mencuci bagian yang terkena najis hingga suci", "4": "Tayamum", "5": "Membasuh wajah", "6": "Wajah, tangan hingga siku, mengusap kepala, kaki hingga mata kaki", "7": "Tetap dianggap memiliki wudu", "8": "Ringan", "9": "Dibasuh tujuh kali, salah satunya dengan tanah/debu suci", "10": "Bertayamum sesuai ketentuan", "11": "Islam", "12": "Matahari tergelincir ke barat", "13": "Mendapatkan rakaat tersebut", "14": "Posisi tubuh", "15": "Mengambil jumlah yang diyakini lebih sedikit lalu menyempurnakan", "16": "Syarat sah", "17": "Bergerak bersamaan atau setelah imam, tidak mendahuluinya", "18": "Memahami ketentuan mazhab/guru dan bertanya untuk memastikan hukum kasusnya", "19": "Berhenti sejenak dengan tenang pada setiap gerakan tertentu", "20": "Duduk sesuai kemampuan", "21": "Mengiringi salat fardu sebelum atau sesudahnya", "22": "Setelah matahari terbit hingga menjelang Zuhur", "23": "Pada malam hari setelah tidur", "24": "Ganjil", "25": "Kusuf", "26": "Hujan", "27": "Masuk masjid sebelum duduk", "28": "Ramadan", "29": "Salat mutlak tidak memiliki sebab atau waktu khusus tertentu", "30": "Memulai dari amalan yang mampu dijaga secara rutin", "31": "Menjadikan hewan halal dimakan sesuai ketentuan", "32": "Tajam dan dapat mengalirkan darah", "33": "Saluran makanan dan saluran napas", "34": "Memahami tata cara dan memenuhi syarat penyembelih", "35": "Ketaatan dan mengingat Allah", "36": "Memberi perlakuan baik dan tidak menyiksanya", "37": "Yang halal dimakan menurut syariat", "38": "Untuk mengurangi penderitaan dan menjaga ihsan kepada hewan", "39": "Ihsan", "40": "Terpenuhi atau tidaknya ketentuan penyembelihan", "41": "Pemberitahuan masuknya waktu salat dan ajakan salat", "42": "Salat berjamaah akan segera dimulai", "43": "Muazin", "44": "Menjawab lafaz adzan sesuai tuntunan", "45": "Marilah melaksanakan salat", "46": "Subuh", "47": "Memiliki suara jelas dan mengetahui waktu salat", "48": "Jemaah salah memahami masuknya waktu salat", "49": "Adzan tanda masuk waktu/seruan salat, iqamah tanda salat segera dimulai", "50": "Tetap mengumandangkan adzan dengan tertib dan mengingatkan secara santun"};
Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 if(req.method!=="POST") return json({error:"Method not allowed"},405);
 try{
  const {access_token,answers,auto_submit=false}=await req.json();
  if(!access_token||!Array.isArray(answers)) return json({error:"Data jawaban tidak lengkap."},400);
  const tokenHash=await hash(access_token);
  const {data:p,error:pe}=await admin.from("participants").select("*").eq("access_token_hash",tokenHash).single();
  if(pe||!p) return json({error:"Sesi peserta tidak valid."},401);
  if(p.submitted_at) return json({error:"Jawaban telah dikirim dan tidak dapat diubah."},409);
  const clean=new Map<number,string>();
  for(const a of answers){const id=Number(a.question_id);if(Number.isInteger(id)&&id>=1&&id<=50&&typeof a.answer==="string") clean.set(id,a.answer)}
  let correct=0,wrong=0;const rows=[];
  for(let id=1;id<=50;id++){const val=clean.get(id)??null;const ok=val!==null&&KEY[String(id)]===val;if(ok)correct++;else if(val!==null)wrong++;rows.push({participant_id:p.id,question_id:id,answer_text:val,is_correct:ok})}
  const unanswered=50-clean.size,score=correct*2;
  const {error:ae}=await admin.from("submission_answers").insert(rows);if(ae)throw ae;
  const {data:updated,error:ue}=await admin.from("participants").update({submitted_at:new Date().toISOString(),correct,wrong,unanswered,score,auto_submitted:!!auto_submit}).eq("id",p.id).is("submitted_at",null).select("id").maybeSingle();
  if(ue||!updated){await admin.from("submission_answers").delete().eq("participant_id",p.id);return json({error:"Pengiriman tidak dapat diproses atau sudah pernah dikirim."},409)}
  return json({result:{name:p.name,klass:p.klass,participant_no:p.participant_no,correct,wrong,unanswered,score}});
 }catch(e){return json({error:"Terjadi kesalahan saat mengoreksi jawaban. Hubungi admin."},500)}
});
