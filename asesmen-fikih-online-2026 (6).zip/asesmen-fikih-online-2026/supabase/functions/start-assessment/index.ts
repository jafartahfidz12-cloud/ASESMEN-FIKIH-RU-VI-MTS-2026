import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, GET, OPTIONS"};
const json = (body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
const admin = createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const hash = async (s:string)=>{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")};

Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 if(req.method!=="POST") return json({error:"Method not allowed"},405);
 try{
  const {name,klass,participant_no,school_year}=await req.json();
  if(!name?.trim()||!klass?.trim()||!participant_no?.trim()) return json({error:"Identitas belum lengkap."},400);
  if(name.length>100||participant_no.length>30) return json({error:"Data identitas terlalu panjang."},400);
  const access_token=crypto.randomUUID()+"-"+crypto.randomUUID();
  const access_token_hash=await hash(access_token);
  const {data,error}=await admin.from("participants").insert({name:name.trim(),klass:klass.trim(),participant_no:participant_no.trim(),school_year:school_year||"2026/2027",access_token_hash}).select("id,name,klass,participant_no,school_year").single();
  if(error){if(error.code==="23505") return json({error:"Nomor peserta ini sudah terdaftar atau telah digunakan. Hubungi pengawas jika ada kesalahan."},409);throw error}
  return json({participant:data,access_token});
 }catch(e){return json({error:"Gagal memulai asesmen."},500)}
});
