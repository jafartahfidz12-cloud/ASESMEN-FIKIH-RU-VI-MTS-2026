import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, GET, OPTIONS"};
const json = (body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
const admin = createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const hash = async (s:string)=>{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")};

Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 const auth=req.headers.get("Authorization")||"";
 const token=auth.replace("Bearer ","");
 if(!token)return json({error:"Login admin diperlukan."},401);
 const userClient=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:`Bearer ${token}`}}});
 const {data:{user},error:ue}=await userClient.auth.getUser();if(ue||!user)return json({error:"Sesi login tidak valid."},401);
 const {data:role}=await admin.from("admin_users").select("user_id").eq("user_id",user.id).maybeSingle();
 if(!role)return json({error:"Akun ini belum diberi hak admin."},403);
 const {data,error}=await admin.from("participants").select("name,klass,participant_no,correct,wrong,unanswered,score,submitted_at,started_at,auto_submitted").order("score",{ascending:false,nullsFirst:false});
 if(error)return json({error:"Tidak dapat membaca data peserta."},500);
 return json({participants:data});
});
