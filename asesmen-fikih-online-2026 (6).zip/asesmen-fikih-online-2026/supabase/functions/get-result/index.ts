import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, GET, OPTIONS"};
const json = (body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
const admin = createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const hash = async (s:string)=>{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")};

Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 try{const {access_token}=await req.json();if(!access_token)return json({error:"Token tidak ada."},400);
 const h=await hash(access_token);const {data:p,error}=await admin.from("participants").select("name,klass,participant_no,correct,wrong,unanswered,score,submitted_at").eq("access_token_hash",h).single();
 if(error||!p)return json({error:"Sesi tidak ditemukan."},404);if(!p.submitted_at)return json({error:"Asesmen belum dikirim."},409);
 return json({result:p});
 }catch{return json({error:"Gagal mengambil hasil."},500)}
});
