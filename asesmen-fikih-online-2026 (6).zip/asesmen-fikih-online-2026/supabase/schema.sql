-- Jalankan seluruh SQL ini di Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.participants (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 klass text not null,
 participant_no text not null unique,
 school_year text not null default '2026/2027',
 access_token_hash text not null unique,
 started_at timestamptz not null default now(),
 submitted_at timestamptz,
 correct integer,
 wrong integer,
 unanswered integer,
 score integer,
 auto_submitted boolean not null default false,
 created_at timestamptz not null default now()
);

create table if not exists public.submission_answers (
 id bigint generated always as identity primary key,
 participant_id uuid not null references public.participants(id) on delete cascade,
 question_id integer not null,
 answer_text text,
 is_correct boolean not null,
 submitted_at timestamptz not null default now(),
 unique(participant_id, question_id)
);

create table if not exists public.admin_users (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);

alter table public.participants enable row level security;
alter table public.submission_answers enable row level security;
alter table public.admin_users enable row level security;

-- Tidak ada policy publik: browser tidak dapat membaca/mengubah tabel langsung.
-- Edge Functions memakai SUPABASE_SERVICE_ROLE_KEY di sisi server.
-- Tambahkan admin setelah membuat akun di Authentication > Users:
-- insert into public.admin_users(user_id) values ('UUID_USER_ADMIN');

create index if not exists participants_score_idx on public.participants(score desc);
create index if not exists participants_class_idx on public.participants(klass);
create index if not exists answers_participant_idx on public.submission_answers(participant_id);
